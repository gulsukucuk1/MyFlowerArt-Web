﻿// buket.js

document.addEventListener("DOMContentLoaded", () => {
    const flowers = document.querySelectorAll(".flower-item");
    const bouquetArea = document.getElementById("bouquet-area");

    // Çiçekleri sürüklenebilir yap
    flowers.forEach(flower => {
        flower.setAttribute("draggable", "true");

        flower.addEventListener("dragstart", (e) => {
            e.dataTransfer.setData("text/plain", e.target.src);
        });
    });

    // Buket alanına sürükleme sırasında görünüm
    bouquetArea.addEventListener("dragover", (e) => {
        e.preventDefault();
        bouquetArea.classList.add("drag-over");
    });

    bouquetArea.addEventListener("dragleave", () => {
        bouquetArea.classList.remove("drag-over");
    });

    // Çiçeği bırakma olayı
    bouquetArea.addEventListener("drop", (e) => {
        e.preventDefault();
        bouquetArea.classList.remove("drag-over");

        const imgSrc = e.dataTransfer.getData("text/plain");

        // Yeni çiçek resmi oluştur
        const newFlower = document.createElement("img");
        newFlower.src = imgSrc;
        newFlower.classList.add("bouquet-flower");

        // Tıklayınca çiçeği sil
        newFlower.addEventListener("click", () => {
            newFlower.remove();
        });

        bouquetArea.appendChild(newFlower);
    });
});
