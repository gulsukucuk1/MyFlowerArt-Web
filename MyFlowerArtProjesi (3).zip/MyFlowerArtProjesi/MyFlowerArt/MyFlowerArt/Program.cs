using Microsoft.EntityFrameworkCore;
using MyFlowerArts.Models;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

// --- 1. SERV�S KAYITLARI (builder.Build'dan �NCE) ---

// Veritaban� Servisi
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Kimlik Do�rulama (Authentication) Servisi
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Login"; // �ifresiz girmeye �al��an� bu sayfaya y�nlendir
        options.AccessDeniedPath = "/Index"; // Yetkisi olmayan� ana sayfaya at
    });

builder.Services.AddRazorPages();

// --------------------------------------------------
var app = builder.Build(); // Bu sat�r sadece bir kez olmal�
// --------------------------------------------------

// --- 2. ARA KATMANLAR (Middleware - S�ralama �NEML�D�R) ---

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// �nce "Kimsin?" (Authentication), sonra "Yetkin var m�?" (Authorization)
app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();

app.Run();