﻿using System.ComponentModel.DataAnnotations;

namespace MyFlowerArts.Models // Buradaki 's' harfine dikkat!
{
    public partial class Order
    {
        [Key]
        public int Id { get; set; }
        public string OrderID { get; set; } = string.Empty;
        public string CustomerName { get; set; } = string.Empty;
        public string OrderDate { get; set; } = string.Empty;
        public string TotalAmount { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
    }
}