using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFlowerArt.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
