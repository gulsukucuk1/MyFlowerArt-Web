using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyFlowerArts.Models;
using Microsoft.AspNetCore.Authorization; // 1. Kilid k�t�phanesini ekledik

namespace MyFlowerArts.Pages.Admin
{
    [Authorize] // 2. KR�T�K SATIR: Bu sayfa art�k �ifresiz giri�e kapal�!
    public class OrdersModel : PageModel
    {
        private readonly AppDbContext _context;

        public OrdersModel(AppDbContext context)
        {
            _context = context;
        }

        public List<Order> AllOrders { get; set; } = new();

        public async Task OnGetAsync()
        {
            // Veritaban�ndaki t�m sipari�leri getirir
            AllOrders = await _context.Orders.OrderByDescending(o => o.Id).ToListAsync();
        }

        // Durum G�ncelleme (Onaylama) Metodu
        public async Task<IActionResult> OnPostUpdateStatusAsync(int id, string newStatus)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order != null)
            {
                order.Status = newStatus;
                await _context.SaveChangesAsync();
            }
            return RedirectToPage();
        }
    }
}