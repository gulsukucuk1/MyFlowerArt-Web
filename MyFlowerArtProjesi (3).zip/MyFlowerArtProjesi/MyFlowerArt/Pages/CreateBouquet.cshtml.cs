using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.IO;

namespace MyFlowerArt.Pages
{
    // JavaScript taraf�ndaki JSON verisini kar��lamak i�in bir s�n�f (Model)
    public class SaveRequest
    {
        public string ImageData { get; set; }
        public string Note { get; set; }
        public string TotalPrice { get; set; }
    }

    [IgnoreAntiforgeryToken] // Fetch iste�inin g�venlik engeline tak�lmamas� i�in �imdilik ekliyoruz
    public class CreateBouquetModel : PageModel
    {
        public void OnGet()
        {
        }

        public IActionResult OnPostSaveImage([FromBody] SaveRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.ImageData))
            {
                return new JsonResult(new { success = false, message = "Veri al�namad�." });
            }

            try
            {
                // JavaScript'ten gelen "data:image/png;base64,..." ba�l���n� temizleyip sadece veriyi al�yoruz
                var base64Data = request.ImageData.Split(',')[1];
                var bytes = Convert.FromBase64String(base64Data);

                // Dosya ad� olu�turma (Benzersiz olmas� i�in tarih kullan�yoruz)
                string fileName = $"bouquet_{DateTime.Now:yyyyMMddHHmmss}.png";

                // Kaydedilecek klas�r�n yolu (wwwroot/saved_bouquets)
                string folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "saved_bouquets");

                // Klas�r yoksa olu�tur
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                string filePath = Path.Combine(folderPath, fileName);

                // Dosyay� diske kaydet
                System.IO.File.WriteAllBytes(filePath, bytes);

                // Ba�ar�l� sonucunu JavaScript'e d�nd�r
                return new JsonResult(new { success = true, path = $"/saved_bouquets/{fileName}" });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { success = false, message = ex.Message });
            }
        }
    }
}