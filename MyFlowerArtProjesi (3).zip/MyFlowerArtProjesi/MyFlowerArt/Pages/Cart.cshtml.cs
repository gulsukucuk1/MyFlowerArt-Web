using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFlowerArts.Pages
{
    public class CartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
