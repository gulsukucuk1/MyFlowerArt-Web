using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFlowerArts.Pages
{
    public class IletisimModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
