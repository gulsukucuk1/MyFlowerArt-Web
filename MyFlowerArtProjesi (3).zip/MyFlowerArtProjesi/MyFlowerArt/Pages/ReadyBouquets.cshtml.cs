using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFlowerArt.Pages
{
    public class ReadyBouquetsModel : PageModel
    {
        public void OnGet()
        {
            // �leride veri taban�ndan haz�r buketleri �ekeceksen buraya yazabilirsin
        }
    }
}
