using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MyFlowerArts.Models;
using System.Threading.Tasks;

namespace MyFlowerArts.Pages
{
    public class CheckoutModel : PageModel
    {
        private readonly AppDbContext _context;

        public CheckoutModel(AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Order NewOrder { get; set; } = new Order();

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            // ModelState.IsValid kontrol� bazen bo� gelen (null) yeni alanlar y�z�nden hata verebilir.
            // Bu y�zden temel alanlar�n dolulu�unu kontrol etmek yeterlidir.
            if (string.IsNullOrEmpty(NewOrder.CustomerName))
            {
                return Page();
            }

            // Sipari�i veritaban�na ekle
            _context.Orders.Add(NewOrder);

            // KR�T�K D�ZELTME: SaveChangesAsync do�rudan _context �zerinden �a�r�l�r.
            await _context.SaveChangesAsync();

            // Takip numaras�n� ba�ar� sayfas�na aktar
            TempData["TrackingID"] = NewOrder.OrderID;

            // Ba�ar� sayfas�na y�nlendir
            return RedirectToPage("/OrderSuccess");
        }
    }
}