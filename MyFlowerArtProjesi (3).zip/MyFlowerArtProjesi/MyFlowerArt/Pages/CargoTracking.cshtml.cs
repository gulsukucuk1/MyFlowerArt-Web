using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MyFlowerArts.Models;

namespace MyFlowerArts.Pages
{
    public class CargoTrackingModel : PageModel
    {
        private readonly AppDbContext _context;

        public CargoTrackingModel(AppDbContext context)
        {
            _context = context;
        }

        // Bulunan sipari�i ekranda g�stermek i�in bu de�i�kende tutaca��z
        public Order? FoundOrder { get; set; }

        public void OnGet()
        {
            // Sayfa ilk a��ld���nda yap�lacak bir i�lem yok
        }

        // Formdaki "Sorgula" butonuna bas�ld���nda bu metod �al���r
        public async Task<IActionResult> OnPostAsync(string trackingNumber)
        {
            if (string.IsNullOrEmpty(trackingNumber))
            {
                return Page();
            }

            // SQL Veritaban�na git ve OrderID'si girilen numara olan sipari�i getir
            FoundOrder = await _context.Orders
                .FirstOrDefaultAsync(o => o.OrderID == trackingNumber);

            return Page();
        }
    }
}