using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFlowerArts.Pages
{
    public class OrderSuccessModel : PageModel
    {
        // �smin TrackingID oldu�undan ve public oldu�undan emin ol
        public string? TrackingID { get; set; }

        public void OnGet()
        {
            TrackingID = TempData["TrackingID"] as string;
        }
    }
}